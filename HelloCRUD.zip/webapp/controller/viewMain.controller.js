sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function(Controller, JSONModel, Filter, FilterOperator, Sorter) {
	"use strict";

	return Controller.extend("HelloWorld.controller.viewMain", {

		onInit: function() {
			this.crudModel = this.getOwnerComponent().getModel("modelContactsCRUD");

			this.onReadPress();
			this.items = new Set();
		},

		// The "U" in CRUD
		onUpdatePress: function(oEvent) {

			var _mandt = oEvent.getSource().getParent().getBindingContext().getProperty("Mandt");
			var _id = oEvent.getSource().getParent().getBindingContext().getProperty("Id");

			var _name = oEvent.getSource().getParent().getBindingContext().getProperty("Name");
			var _email = oEvent.getSource().getParent().getBindingContext().getProperty("Email");

			var _this = this;

			var oEntry = {
				"Name": _name,
				"Email": _email
			};

			this.crudModel.update("/CONTACTSENTITYSet(Mandt='" + _mandt + "',Id='" + _id + "')", oEntry, {
				success: function(executionResult) {
					alert("Updated!");
					_this.onReadPress();
				},
				error: function(callError) {
					alert(callError.message + "\n" + callError.responseText);
				}
			});

		},

		// The "D" in CRUD
		onDeletePress: function(oEvent) {
			console.log(this.checked);
			// var _mandt= oEvent.getSource().getParent().getBindingContext().getProperty("Mandt") ;
			// var _id= oEvent.getSource().getParent().getBindingContext().getProperty("Id") ;
			var _this = this;
			this.crudModel.remove("/CONTACTSENTITYSet(Mandt='" + this.checked + "',Id='" + this.id + "')", {
				success: function(executionResult) {
					alert("Deleted!");
					_this.onReadPress();
				},
				error: function(callError) {
					alert(callError.message + "\n" + callError.responseText);
				}
			});

		},
		onChecked: function(oEvent) {
			var _checked = oEvent.getSource().getParent().getBindingContext().getProperty("Mandt");
			var _id = oEvent.getSource().getParent().getBindingContext().getProperty("Id");
			//var _this = this ;
			//this.checked = _checked;
			var selected = oEvent.getParameter("selected");
			if (selected) {
				this.items.add(_id);
			}
			else {
				this.items.delete(_id);
			}

			console.log(this.items);
			//console.log(_id)
		},

		// The "R" in CRUD
		onReadPress: function(oEvent) {

			var _this = this;

			var allFilters = [];
			var filter1 = new Filter({
				path: "Id",
				operator: FilterOperator.EQ,
				value1: "80"
			});
			allFilters.push(filter1);

			this.crudModel.read("/CONTACTSENTITYSet", {
				method: "GET",
				filters: allFilters,
				success: function(responseData) {
					var readModel = new JSONModel();
					readModel.setData(responseData);
					_this.getView().setModel(readModel);

				},
				error: function(callError) {
					alert(callError.message + "\n" + callError.responseText);
				}
			});

		},

		// The "C" in CRUD	
		onCreatePress: function(oEvent) {

			var oEntry = {
				"Mandt": "100",
				"Id": "",
				"Name": this.getView().byId("newName").getValue(),
				"Email": this.getView().byId("newEmail").getValue()
			};

			this.crudModel.create("/CONTACTSENTITYSet", oEntry, {
				method: "POST",
				success: function(executionResult) {
					alert("Created!");
				},
				error: function(callError) {
					alert(callError.message + "\n" + callError.responseText);
				}
			});

		},

		onFilterValueChanged: function(oEvent) {

			var tableFilter = null;
			var textFieldValue = oEvent.getParameter("value");

			if (textFieldValue) {
				tableFilter = [new Filter("Name", FilterOperator.Contains, textFieldValue)];
			}

			this.getView().byId("tablePeople").getBinding("items").filter(tableFilter);

			// Datele din tabel vin dintr'o sursa ( model )
			// Modelul e legat la tabel printr'un BINDING
			// Daca vreau sa filtrez ce e in tabel , trebuie sa "umblu" la modelul in sine
			// lucru pe care il fac prin intermediul bindingului.
			//
			// this - obicetul curent in care ma aflu . aici : CONTROLLERUL
			// .getView() - o metoda a controllerului care returneaza view'ul de care apartine controllerul
			// .byId() - o metoda a view'ului
			// .getBindings("items") - metoda care returneaza handle catre datele care sunt binduite pe agregarea de "items"
			// .filter() - metoda care sorteaza datele in sine

		},

		onSortPressed: function(oEvent) {

			this.getView().byId("tablePeople").getBinding("items").sort(new Sorter("Name", false));

		}

	});
});